const express = require('express');
const session = require('express-session');
const bodyParser = require('body-parser');
const hb = require('express-handlebars');
const app = express();
const mysql = require('mysql');

const port = 3000;
const pool = mysql.createPool({
    host     : 'localhost',
    user     : 'divya',
    password : 'password',
    database : 'beaversfirst',
    multipleStatements : true,
    connectionLimit : 4
});

app.use(express.static('static'));
app.use(bodyParser.urlencoded({ extended: false }));
app.engine('handlebars', hb({defaultLayout: 'main'}));
app.set('view engine', 'handlebars');

// queries
const query_users = 'SELECT * FROM users WHERE id=? AND password=?;'
const query_student = 'SELECT firstname,lastname,address,email,phno FROM student WHERE empl_id=?;'
const query_courses = 'SELECT course_id, course_name, instructor FROM courses WHERE term=? AND department=?;'
const query_departmentList = 'SELECT unique(dept) from library;'
const query_library = 'SELECT isbn,bookname,author FROM library WHERE dept=?;'
const query_term = 'SELECT unique(term) from courses;'

function db(req, res, next) {
    pool.getConnection((error, connection) => {
        try {
            if (error) {
                console.error('Error connecting to the database.', error);
                res.render('error', { error });
            } else {
                req.connection = connection;
                next();
            }
        } finally {
            connection.release();
        }
    });
}

function debuglog(req, res, next) {
    console.debug(`${req.method} -- ${req.path} (params: ${JSON.stringify(req.params)}) [body: ${JSON.stringify(req.body)}]`);
    next();
}

function getDetails(req, res,id){
  return new Promise((resolve, reject) => {
    ;
    req.connection.query(query_student, id,(error, result) => {
    if(result)
    {
      console.log(result);
      resolve (result);
    }
  });
  });
}

function getDepartment(req){
  return new Promise((resolve, reject) => {
    ;
    req.connection.query(query_departmentList ,(error, result) => {
    if(result)
    {
      console.log(result);
      resolve (result);
    }
  });
  });
}

function getTerm(req){
  return new Promise((resolve, reject) => {
    ;
    req.connection.query(query_term ,(error, result) => {
    if(result)
    {
      console.log(result);
      resolve (result);
    }
  });
  });
}


app.get('/', (req,res) => {
  res.render('login');
});

app.get('/courses', db, (req,res) => {
  getTerm(req).then( termList =>{
    console.log(termList);
  res.render('courses', {termList});
  })
});

app.get('/library', db, (req,res) => {
  getDepartment(req).then( deptList =>{
  res.render('library', {deptList});
  })

});

app.get('/stream', (req,res) => {
  res.render('stream');
});


app.post('/', debuglog, db, function (req, res) {
    req.connection.query(query_users, [parseInt(req.body.user,10),req.body.password], (error, result) => {
        if (error) {
            console.error('Error logging in.', error);
            res.render('error', { error });
        } else {
            if (result.length > 0) {
              let userId = result[0].id;
              getDetails(req, res ,userId).then( (details) =>{
                //console.log(`${details}     ${details[0]}`);
                res.render('personal',details[0]);
              });


            } else {
                res.render('login');
                console.error('Error logging in, unexpected result set.');
            }
        }
    });
});

app.post('/library', debuglog, db, function (req, res) {
    req.connection.query(query_library, [req.body.library], (error, result) => {
        if (error) {
            res.render('error', { error });
        } else {
            // console.log(req.body.library);
            // console.log(result);
            if (result.length > 0) {
              // console.log(result);
              res.render('books',{result});
            }
            else {
                console.error('Connot render books');
            }
        }
    });
});

app.post('/courses', debuglog, db, function (req, res) {
    req.connection.query(query_courses, [req.body.term,req.body.department], (error, result) => {
        if (error) {
            res.render('error', { error });
        } else {
            console.log(req.body.library);
            console.log(result);
            if (result.length > 0) {
              // console.log(result);
              res.render('courselist',{result});
            }
            else {
                console.error('Connot render courselist');
            }
        }
    });
});



app.listen(3000);
