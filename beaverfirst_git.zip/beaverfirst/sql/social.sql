DROP DATABASE IF EXISTS beaversfirst;
CREATE DATABASE beaversfirst;
USE beaversfirst;

--{{{ Table Definitions

DROP TABLE IF EXISTS student;
CREATE TABLE student(
    empl_id INTEGER PRIMARY KEY AUTO_INCREMENT,
    firstname VARCHAR(32) NOT NULL,
    lastname VARCHAR(32) NOT NULL,
    address VARCHAR(32),
    email VARCHAR(32) NOT NULL,
    phno VARCHAR(32) NOT NULL
);

DROP TABLE IF EXISTS users;
CREATE TABLE users(
    id INTEGER UNIQUE NOT NULL,
    password VARCHAR(16) NOT NULL,
    FOREIGN KEY(id) REFERENCES student(empl_id)
);

DROP TABLE IF EXISTS courses;
CREATE TABLE courses(
    course_id VARCHAR(16) PRIMARY KEY,
    course_name VARCHAR(32) NOT NULL,
    department VARCHAR(32),
    instructor VARCHAR(32),
    term VARCHAR(16)
);

DROP TABLE IF EXISTS library;
CREATE TABLE library(
    isbn INTEGER PRIMARY KEY AUTO_INCREMENT,
    dept VARCHAR(32),
    bookname VARCHAR(64) NOT NULL,
    author VARCHAR(64)
);

-- DROP TABLE IF EXISTS coursehistory;
-- CREATE TABLE coursehistory(
--     s_id INTEGER,
--     c_id INTEGER,
--     term VARCHAR(16) NOT NULL,
--     PRIMARY KEY(s_id, c_id),
--     FOREIGN KEY(s_id) REFERENCES student(empl_id),
--     FOREIGN KEY(c_id) REFERENCES courses(id)
-- );

-- }}}

-- {{{ Insert test data.
INSERT INTO student VALUES (100, 'Divya', 'Sankar','127, Englewood Avenue, NY 10523','divyasankar@beaversfirst.com',9141234567);
INSERT INTO student VALUES (200, 'Marjan', 'Rezvani','25, Martine Avenue, NY 10606','marjanrez@beaversfirst.com',9149876543);
INSERT INTO student VALUES (300, 'Deepak', 'Kumar','181, Oakhill Dive, NY 10413','deepakkumar@beaversfirst.com',9144561290);

INSERT INTO users VALUES (100, 'xyz123');
INSERT INTO users VALUES (200, 'abc123');
INSERT INTO users VALUES (300, 'password');

INSERT INTO courses VALUES ('CSC1000', 'Database Systems', 'Computer Science','John Connor','Fall 2020');
INSERT INTO courses VALUES ('CSC471', 'Computer Vision', 'Computer Science','Zhigang Zhu','Spring 2020');
INSERT INTO courses VALUES ('CSC7200', 'Distributed Systems', 'Computer Science','Ravindran Kaliappa','Fall 2020');
INSERT INTO courses VALUES ('CSC5000', 'Oparating Systems', 'Computer Science','Devendra Kumar','Fall 2020');
INSERT INTO courses VALUES ('CSC1050', 'Web Security', 'Computer Science','Rosario G','Fall 2020');
INSERT INTO courses VALUES ('DSE1210', 'Machine Learning', 'Data Science and Engineering','Michael Grossberg','Spring 2020');
INSERT INTO courses VALUES ('DSE1030', 'Applied Statistics', 'Data Science and Engineering','Irina Gladkova','Fall 2020');
INSERT INTO courses VALUES ('DSE1910', 'Neural Networks', 'Data Science and Engineering','Michael Grossberg','Fall 2020');
INSERT INTO courses VALUES ('DSE1050', 'Big Data', 'Data Science and Engineering','Huy Vo','Spring 2020');

INSERT INTO library VALUES (1234,'Computer Science','Database Systems - The Complete Book','Garcia-Molina, Jeffrey, Ullman, and Widom');
INSERT INTO library VALUES (1235,'Computer Science','Introduction to ALgorithms','Thomas H.Corman ');
INSERT INTO library VALUES (1531,'Data Science and Engineering','Machine Learning','Tom M. Mitchell');
INSERT INTO library VALUES (1532,'Data Science and Engineering','Deep Learning with Python','François Chollet');
-- }}}
