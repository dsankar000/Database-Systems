DROP DATABASE IF EXISTS beaversfirst;
CREATE DATABASE beaversfirst;
USE beaversfirst;

--{{{ Table Definitions
DROP TABLE IF EXISTS users;
CREATE TABLE users(
    id VARCHAR(10) PRIMARY KEY,
    password VARCHAR(16) NOT NULL
);

DROP TABLE IF EXISTS student;
CREATE TABLE student(
    empl_id VARCHAR(10) PRIMARY KEY,
    firstname VARCHAR(32) NOT NULL,
    lastname VARCHAR(32) NOT NULL,
    address VARCHAR(32),
    email VARCHAR(32) NOT NULL,
    phno VARCHAR(32) NOT NULL
);

DROP TABLE IF EXISTS admin;
CREATE TABLE admin(
    empl_id VARCHAR(10) PRIMARY KEY,
    firstname VARCHAR(32) NOT NULL,
    lastname VARCHAR(32) NOT NULL,
    email VARCHAR(32) NOT NULL
);

DROP TABLE IF EXISTS courses;
CREATE TABLE courses(
    course_id VARCHAR(16) PRIMARY KEY,
    course_name VARCHAR(32) NOT NULL,
    department VARCHAR(32),
    instructor VARCHAR(32),
    term VARCHAR(16)
);

DROP TABLE IF EXISTS library;
CREATE TABLE library(
    isbn INTEGER PRIMARY KEY AUTO_INCREMENT,
    dept VARCHAR(32),
    bookname VARCHAR(64) NOT NULL,
    author VARCHAR(64)
);

-- Relationship Tables
DROP TABLE IF EXISTS EnrollsIn;
CREATE TABLE EnrollsIn(
	s_id VARCHAR(10),
	c_id VARCHAR(16),
	PRIMARY KEY(s_id, c_id),
  FOREIGN KEY(s_id) REFERENCES student(empl_id),
  FOREIGN KEY(c_id) REFERENCES courses(course_id)
);


DROP TABLE IF EXISTS reference;
CREATE TABLE reference(
	c_id VARCHAR(16),
	isbn INTEGER,
	PRIMARY KEY(c_id, isbn),
  FOREIGN KEY(c_id) REFERENCES courses(course_id),
  FOREIGN KEY(isbn) REFERENCES library(isbn)
);

DROP TABLE IF EXISTS Manage;
CREATE TABLE Manage(
	s_id VARCHAR(10),
	c_id VARCHAR(16),
	PRIMARY KEY( s_id,c_id),
  FOREIGN KEY(s_id) REFERENCES admin(empl_id),
  FOREIGN KEY(c_id) REFERENCES courses(course_id)
);


--}}}

-- {{{ Insert test data.
INSERT INTO student VALUES ('ds100', 'Divya', 'Sankar','127, Englewood Avenue, NY 10523','divyasankar@beaversfirst.com',9141234567);
INSERT INTO student VALUES ('mr200', 'Marjan', 'Rezvani','25, Martine Avenue, NY 10606','marjanrez@beaversfirst.com',9149876543);
INSERT INTO student VALUES ('dk300', 'Deepak', 'Kumar','181, Oakhill Dive, NY 10413','deepakkumar@beaversfirst.com',9144561290);

INSERT INTO admin VALUES ('admin', 'Jessica', 'Thompson','jthompson@beaversfirst.com');

INSERT INTO users VALUES ('ds100','xyz123');
INSERT INTO users VALUES ('mr200','abc123');
INSERT INTO users VALUES ('dk300','password');
INSERT INTO users VALUES ('admin','admin');

INSERT INTO courses VALUES ('CSC1000', 'Database Systems', 'Computer Science','John Connor','Fall 2020');
INSERT INTO courses VALUES ('CSC471', 'Computer Vision', 'Computer Science','Zhigang Zhu','Spring 2020');
INSERT INTO courses VALUES ('CSC7200', 'Distributed Systems', 'Computer Science','Ravindran Kaliappa','Fall 2020');
INSERT INTO courses VALUES ('CSC5000', 'Oparating Systems', 'Computer Science','Devendra Kumar','Fall 2020');
INSERT INTO courses VALUES ('CSC1050', 'Web Security', 'Computer Science','Rosario G','Fall 2020');
INSERT INTO courses VALUES ('DSE1210', 'Machine Learning', 'Data Science and Engineering','Michael Grossberg','Spring 2020');
INSERT INTO courses VALUES ('DSE1030', 'Applied Statistics', 'Data Science and Engineering','Irina Gladkova','Fall 2020');
INSERT INTO courses VALUES ('DSE1910', 'Neural Networks', 'Data Science and Engineering','Michael Grossberg','Fall 2020');
INSERT INTO courses VALUES ('DSE1050', 'Big Data', 'Data Science and Engineering','Huy Vo','Spring 2020');

INSERT INTO library VALUES (1234,'Computer Science','Database Systems - The Complete Book','Garcia-Molina, Jeffrey, Ullman, and Widom');
INSERT INTO library VALUES (1235,'Computer Science','Introduction to ALgorithms','Thomas H.Corman ');
INSERT INTO library VALUES (1531,'Data Science and Engineering','Machine Learning','Tom M. Mitchell');
INSERT INTO library VALUES (1532,'Data Science and Engineering','Deep Learning with Python','François Chollet');

INSERT INTO EnrollsIn VALUES ('ds100', 'CSC1000');
INSERT INTO EnrollsIn VALUES ('ds100', 'CSC471');
INSERT INTO EnrollsIn VALUES ('ds100', 'DSE1910');
INSERT INTO EnrollsIn VALUES ('mr200', 'CSC1000');
INSERT INTO EnrollsIn VALUES ('mr200', 'DSE1030');
INSERT INTO EnrollsIn VALUES ('mr200', 'DSE1050');
INSERT INTO EnrollsIn VALUES ('dk300', 'DSE1210');
INSERT INTO EnrollsIn VALUES ('dk300', 'CSC5000');
INSERT INTO EnrollsIn VALUES ('dk300', 'CSC7200');


INSERT INTO reference VALUES ('CSC1000', 1234);
INSERT INTO reference VALUES ('DSE1210', 1531);
INSERT INTO reference VALUES ('DSE1910', 1532);




-- }}}
